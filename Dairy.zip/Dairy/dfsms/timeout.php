<script>
  var images = [
  "bg.jpg",
  "login.jpg",
  "cows-dairy.jpg"
];

// Function to change the background image
function changeBackground() {
  var randomIndex = Math.floor(Math.random() * images.length);
  var imageUrl = "path/to/images/" + images[randomIndex];
  document.body.style.backgroundImage = "url('" + imageUrl + "')";
}

// Delay in milliseconds before changing the background image
var delayInMilliseconds = 5000; // 5 seconds

// Call the function after the specified delay
setTimeout(changeBackground, delayInMilliseconds);
		
		
		
		</script>