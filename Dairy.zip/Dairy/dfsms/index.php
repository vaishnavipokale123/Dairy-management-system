<html>


<style>

lable{
width:100px;
display:inline-block;
margin: 0.2cm;
font-size:1.2rem;
}
.container{
padding-top: 15px;
padding-left: 30px;
padding-right: 30px;
padding-bottom: 100px;
background-color:Red;
margin-top: 50px;
margin-bottom:0px;
margin-left: 400px;
margin-right:400px;
font-face:calibry;


}


h1{
color:Black;
font-size:3.5rem;
font-face:arial;
}
input[type=submit]{
border:none;
background-color:Black;
}
input[type=text],[type=password]{
	padding-left:15px;

</style>













<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(isset($_POST['login']))
  {
    $adminuser=$_POST['username'];
    $password=md5($_POST['password']);
    $query=mysqli_query($con,"select ID from tbladmin where  UserName='$adminuser' && Password='$password' ");
    $ret=mysqli_fetch_array($query);
    if($ret>0){
      $_SESSION['aid']=$ret['ID'];
     header('location:dashboard.php');
    }
    else{
     echo "<script>alert('Invalid details. Please try again.');</script>";   
   echo "<script>window.location.href='index.php'</script>";
    }
  }
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>Login Page</title>
    <meta name="description" content="A responsive bootstrap 4 admin dashboard template by hencework" />
	
	
	
	
	
	
	
	
	

    
</head>
<body>
 <div class="hk-pg-wrapper" style="background-image: url('./dist/img/one.jpg'); background-size: cover; background-repeat: no-repeat;">
 
</body>
<center><br>
    <h1> Dairy  Management System </h1>
</center>
<body>

   <!-- HK Wrapper -->
   <div class="hk-wrapper">

<!-- Main Content -->
<div class="hk-pg-wrapper hk-auth-wrapper">
    <header class="d-flex justify-content-between align-items-center">
<a class="d-flex auth-brand align-items-center" href="#">
    </a>
               
               </header>
               <div class="container-fluid">
                   <div class="row">
				   
				   
				   
				   
				   
				   
				   
				 
					
					
					
					
                       
                       <div class="col-xl-7 pa-0">
                           <div class="auth-form-wrap py-xl-0 py-50">
        <div class="auth-form w-xxl-55 w-xl-75 w-sm-90 w-xs-100">
                                   <form method="post">
                                    <center><br><br>
                                       <h1 class="display-4 mb-10">Welcome :</h1>  
                                        </center>             
  


<center>                              
<div class="form-group"><br>
<input class="form-control" placeholder="username" type="text" name="username" required="true"  style="width:250px; height: 40px;"   >
</div>

<div class="form-group">
<div class="input-group"><br>
<input class="form-control" placeholder="Password" id = "pass" type="password" name="password" required="true"  style="width:250px; height: 40px;" ><br>
<div class="input-group-append"><br>
<input type="checkbox" onclick="myFunction()" style="width:20px; height: 20px;">Show password
        <script type="text/javascript" >function myFunction() {
          var x = document.getElementById("pass");
          if (x.type === "password") {
            x.type = "text"; 
          } else {
            x.type = "password";
          }
        }</script>
		
</div>
</div>
</div>
 <br>                         
<button class="btn btn-warning btn-block" type="submit" name="login" style="width:100px; height: 40px;" >Login</button><br>
<p class "font-14 text-center mt-15">Having truble login in ?</p>
</center>
     
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Main Content -->

    </div>
    <!-- /HK Wrapper -->

    <!-- jQuery -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Slimscroll JavaScript -->
    <script src="dist/js/jquery.slimscroll.js"></script>

    <!-- Fancy Dropdown JS -->
    <script src="dist/js/dropdown-bootstrap-extended.js"></script>

    <!-- Owl JavaScript -->
    <script src="vendors/owl.carousel/dist/owl.carousel.min.js"></script>

    <!-- FeatherIcons JavaScript -->
    <script src="dist/js/feather.min.js"></script>

    <!-- Init JavaScript -->
    <script src="dist/js/init.js"></script>
    <script src="dist/js/login-data.js"></script>
	<h1 style="background-color:pink;">...</h1>
</body>

</html>