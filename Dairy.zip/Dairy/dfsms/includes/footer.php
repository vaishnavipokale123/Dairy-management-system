            <div class="hk-footer-wrap container">
                <footer class="footer">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">

                        </div>
                    </div>
                </footer>
            </div>